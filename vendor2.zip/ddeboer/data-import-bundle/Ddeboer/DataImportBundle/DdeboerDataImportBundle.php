<?php

namespace Ddeboer\DataImportBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DdeboerDataImportBundle extends Bundle
{
}
