<?php

namespace Ddeboer\DataImport;

/**
 * Base exception
 *
 * @author David de Boer <david@ddeboer.nl>
 */
interface Exception
{

}
