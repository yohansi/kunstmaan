<?php

namespace Ddeboer\DataImport\Exception;

use Ddeboer\DataImport\Exception;

/**
 * Description of MappingException
 *
 * @author gnat
 */
class MappingException extends \Exception implements Exception
{

}
