<?php

namespace Ddeboer\DataImport\Exception;

use Ddeboer\DataImport\Exception;

/**
 * @author Markus Bachmann <markus.bachmann@bachi.biz>
 */
class SourceNotFoundException extends \Exception implements Exception
{

}
