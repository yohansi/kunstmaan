<?php

namespace Ddeboer\DataImport\Exception;

use Ddeboer\DataImport\Exception;

/**
 * @author David de Boer <david@ddeboer.nl>
 */
class WriterException extends \Exception implements Exception
{

}
