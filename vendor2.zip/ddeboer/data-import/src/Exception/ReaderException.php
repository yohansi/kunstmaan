<?php

namespace Ddeboer\DataImport\Exception;

/**
 * @author David de Boer <david@ddeboer.nl>
 */
class ReaderException extends UnexpectedValueException
{

}
