<?php

namespace Ddeboer\DataImport\Exception;

use Ddeboer\DataImport\Exception;

/**
 * @author David de Boer <david@ddeboer.nl>
 */
class UnexpectedValueException extends \UnexpectedValueException implements Exception
{

}

