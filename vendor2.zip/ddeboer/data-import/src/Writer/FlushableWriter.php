<?php

namespace Ddeboer\DataImport\Writer;

interface FlushableWriter
{
    public function flush();
}
