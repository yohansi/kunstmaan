1.1.0 / 2015-09-28
==================

 * Updated unicode bank files
 * Added a testsuite for the library

1.0.1 / 2014-05-14
==================

 * fixed the regex used to replace non-word characters

1.0.0 / 2014-01-12
==================

 * Initial release as a standalone component
