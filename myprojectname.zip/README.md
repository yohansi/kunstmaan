Kunstmaan Bundles Standard Edition
==================================

Welcome to the Kunstmaan Bundles Standard Edition - a fully-functional CMS (content management system) based on Symfony that you can use as the skeleton for your websites. Please refer to the documentation at [http://bundles.kunstmaan.be/getting-started](http://bundles.kunstmaan.be/getting-started) to get your CMS up and running.

![Screenshot](http://bundles.kunstmaan.be/uploads/media/521f4ef030de9.png?7dd5040)

Enjoy!

[![Build Status](https://travis-ci.org/Kunstmaan/KunstmaanBundlesStandardEdition.png?branch=master)](http://travis-ci.org/Kunstmaan/KunstmaanBundlesStandardEdition)
[![Total Downloads](https://poser.pugx.org/kunstmaan/bundles-standard-edition/downloads.png)](https://packagist.org/packages/kunstmaan/bundles-standard-edition)
[![Latest Stable Version](https://poser.pugx.org/kunstmaan/bundles-standard-edition/v/stable.png)](https://packagist.org/packages/kunstmaan/bundles-standard-edition)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/Kunstmaan/KunstmaanBundlesCMS/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/Kunstmaan/KunstmaanBundlesCMS/?branch=master)
[![Code Coverage](https://scrutinizer-ci.com/g/Kunstmaan/KunstmaanBundlesStandardEdition/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/Kunstmaan/KunstmaanBundlesStandardEdition/?branch=master)
