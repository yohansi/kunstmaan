<?php

namespace Liip\ImagineBundle\Exception\Binary\Loader;

use Liip\ImagineBundle\Exception\ExceptionInterface;

class NotLoadableException extends \RuntimeException implements ExceptionInterface
{
}
