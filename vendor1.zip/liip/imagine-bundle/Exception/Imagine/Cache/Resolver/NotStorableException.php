<?php

namespace Liip\ImagineBundle\Exception\Imagine\Cache\Resolver;

use Liip\ImagineBundle\Exception\ExceptionInterface;

class NotStorableException extends \RuntimeException implements ExceptionInterface
{
}
