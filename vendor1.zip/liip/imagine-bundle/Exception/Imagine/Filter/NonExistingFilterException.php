<?php

namespace Liip\ImagineBundle\Exception\Imagine\Filter;

use Liip\ImagineBundle\Exception\ExceptionInterface;

class NonExistingFilterException extends \RuntimeException implements ExceptionInterface
{
}
