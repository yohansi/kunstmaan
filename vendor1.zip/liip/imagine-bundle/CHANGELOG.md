Changelog
=========

* **2013-09-17**: [PHPCR loader] DoctrinePHPCRLoader is now deprecated, as the
  CmfMediaBundle provides a more reliable loader that is already provided as a
  service. See http://symfony.com/doc/master/cmf/bundles/media.html#liipimagine