<?php

namespace Liip\ImagineBundle;

interface ImagineEvents
{
    const PRE_RESOLVE = 'liip_imagine.pre_resolve';

    const POST_RESOLVE = 'liip_imagine.post_resolve';
}
