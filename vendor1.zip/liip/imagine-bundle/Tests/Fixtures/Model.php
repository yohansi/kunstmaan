<?php

namespace Guzzle\Service\Resource;

class Model
{
    public function get($key)
    {
    }
}
